<?= view('templates/header') ?>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        <!-- Display Flash Messages (Success/Error/Info) -->
        <?php if (session()->getFlashdata('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded my-4" role="alert">
                <?= session()->getFlashdata('success') ?>
            </div>
        <?php endif; ?>

        <div class="bg-white shadow-xl rounded-xl p-8">
            <h2 class="text-3xl font-semibold text-gray-800 mb-6">Welcome to Philippines, <?= esc($user_name) ?>!</h2>

            <p class="text-lg text-gray-600 mb-8">This page is only accessible to authenticated users.</p>

            <div class="space-y-4">
                <div class="bg-indigo-50 p-4 rounded-lg flex items-center">
                    <svg class="w-6 h-6 text-indigo-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                    <p class="text-gray-700"><span class="font-medium">User Name:</span> <?= esc($user_name) ?></p>
                </div>
                <div class="bg-indigo-50 p-4 rounded-lg flex items-center">
                    <svg class="w-6 h-6 text-indigo-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                    <p class="text-gray-700"><span class="font-medium">Email:</span> <?= esc($user_email) ?></p>
                </div>
                <div class="bg-indigo-50 p-4 rounded-lg flex items-center">
                    <svg class="w-6 h-6 text-indigo-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.001 12.001 0 002.944 12c.045 4.093 2.067 7.747 5.094 10.424z"></path></svg>
                    <p class="text-gray-700"><span class="font-medium">User Role:</span> <span class="uppercase font-bold text-indigo-700"><?= esc($user_role) ?></span></p>
                </div>
            </div>

            <!-- Role-specific content -->
            <?php if ($user_role === 'admin'): ?>
                <div class="mt-10 bg-red-50 p-6 rounded-lg">
                    <h3 class="text-xl font-medium text-red-700 mb-4">Admin Panel</h3>
                    <p class="text-red-600">As an admin, you have full access to manage users, system settings, and more.</p>
                    <ul class="list-disc list-inside text-red-600 mt-2">
                        <li>Manage Users</li>
                        <li>System Configuration</li>
                        <li>View Reports</li>
                    </ul>
                </div>
            <?php elseif ($user_role === 'teacher'): ?>
                <div class="mt-10 bg-blue-50 p-6 rounded-lg">
                    <h3 class="text-xl font-medium text-blue-700 mb-4">Teacher Dashboard</h3>
                    <p class="text-blue-600">As a teacher, you can manage your classes, assignments, and student progress.</p>
                    <ul class="list-disc list-inside text-blue-600 mt-2">
                        <li>View Classes</li>
                        <li>Assign Tasks</li>
                        <li>Grade Students</li>
                    </ul>
                </div>
            <?php elseif ($user_role === 'student'): ?>
                <div class="mt-10 bg-green-50 p-6 rounded-lg">
                    <h3 class="text-xl font-medium text-green-700 mb-4">Student Portal</h3>
                    <p class="text-green-600">As a student, access your courses, assignments, and grades.</p>
                    <ul class="list-disc list-inside text-green-600 mt-2">
                        <li>View Courses</li>
                        <li>Submit Assignments</li>
                        <li>Check Grades</li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
