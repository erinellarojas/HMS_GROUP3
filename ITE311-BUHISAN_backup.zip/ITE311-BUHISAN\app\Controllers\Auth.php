<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Auth extends Controller
{
    protected $db; // Database connection instance

    public function __construct()
    {
        // Get the database connection
        $this->db = \Config\Database::connect();
        // Load the session service for use in all methods
        $this->session = \Config\Services::session();
        // Ensure the helper is loaded for setting flash messages
        helper(['form', 'url']);
    }

    // --- Registration (Step 4) ---
    public function register()
    {
        $data = [];
        $data['validation'] = \Config\Services::validation();

        if ($this->request->getMethod() == 'post') {
            // Set validation rules
            $rules = [
                'name' => 'required|min_length[3]|max_length[100]',
                'email' => 'required|valid_email|is_unique[users.email]',
                'password' => 'required|min_length[8]',
            ];

            if ($this->validate($rules)) {
                $userData = [
                    'name'     => $this->request->getPost('name'),
                    'email'    => $this->request->getPost('email'),
                    // Step 4: Hash the password securely
                    'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
                    'role'     => 'student', // Default role
                    'created_at' => date('Y-m-d H:i:s'),
                ];

                try {
                    // Save data to the 'users' table
                    $this->db->table('users')->insert($userData);

                    // Step 4: Set success flash message and redirect
                    $this->session->setFlashdata('success', 'Registration successful! Please log in.');
                    return redirect()->to('/login');
                } catch (\Exception $e) {
                    // Handle database errors
                    $this->session->setFlashdata('error', 'Registration failed due to a system error. Please try again.');
                    return redirect()->back()->withInput();
                }
            } else {
                // Validation failed, errors are automatically available via the service
                $data['validation'] = $this->validator;
            }
        }

        // Load the registration view
        return view('auth/register', $data);
    }

    // --- Login (Step 5) ---
    public function login()
    {
        $data = [];
        $data['validation'] = \Config\Services::validation();

        if ($this->request->getMethod() == 'post') {
            // Set validation rules
            $rules = [
                'email' => 'required|valid_email',
                'password' => 'required|min_length[8]',
            ];

            if ($this->validate($rules)) {
                $email = $this->request->getPost('email');
                $password = $this->request->getPost('password');

                // Check the database for a user with the provided email
                $user = $this->db->table('users')->where('email', $email)->get()->getRow();

                if ($user) {
                    // Step 5: Verify the password hash
                    if (password_verify($password, $user->password)) {
                        // Correct credentials: create session data
                        $sessionData = [
                            'user_id'    => $user->id,
                            'name'       => $user->name,
                            'email'      => $user->email,
                            'role'       => $user->role,
                            'isLoggedIn' => TRUE
                        ];
                        
                        $this->session->set($sessionData);
                        $this->session->setFlashdata('success', 'Welcome back, ' . $user->name . '!');
                        
                        // Redirect to the protected dashboard
                        return redirect()->to('/dashboard');
                    } else {
                        // Incorrect password
                        $this->session->setFlashdata('error', 'Invalid Email or Password.');
                        return redirect()->back()->withInput();
                    }
                } else {
                    // User not found
                    $this->session->setFlashdata('error', 'Invalid Email or Password.');
                    return redirect()->back()->withInput();
                }
            } else {
                // Validation failed
                $data['validation'] = $this->validator;
            }
        }

        // Load the login view
        return view('auth/login', $data);
    }

    // --- Logout (Step 6) ---
    public function logout()
    {
        // Step 6: Destroy the current session
        $this->session->destroy();
        $this->session->setFlashdata('info', 'You have been successfully logged out.');
        return redirect()->to('/login');
    }

    // --- Protected Dashboard (Step 6) ---
    public function dashboard()
    {
        // Step 6: Check if the user is logged in
        if (!$this->session->get('isLoggedIn')) {
            return redirect()->to('/login');
        }

        $data['user_name'] = $this->session->get('name');
        $data['user_role'] = $this->session->get('role');
        $data['user_email'] = $this->session->get('email');

        return view('auth/dashboard', $data);
    }
}