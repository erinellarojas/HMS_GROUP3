<?php

$session = \Config\Services::session();
$isLoggedIn = $session->get('isLoggedIn');
$userRole = $session->get('role');
$userName = $session->get('name');
?>

<header class="bg-indigo-700 shadow-xl">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
            <div class="flex items-center">
                <!-- Branding / Project Title -->
                <a href="/" class="text-white text-2xl font-extrabold tracking-wider hover:text-indigo-100 transition duration-150">
                    ITE311-PROJECT
                </a>
            </div>
            
            <nav class="flex space-x-2 sm:space-x-4 items-center">
                <?php if ($isLoggedIn): ?>
                    <!-- Common Logged-in Link -->
                    <a href="/dashboard" class="text-indigo-200 hover:bg-indigo-600 hover:text-white px-3 py-2 rounded-lg text-sm font-medium transition duration-150">
                        Dashboard
                    </a>

                    <!-- Step 5: Role-Specific Links -->
                    <?php if ($userRole === 'admin'): ?>
                        <!-- Admin Links (e.g., Settings, Management) -->
                        <a href="#" class="text-yellow-300 hover:bg-indigo-600 hover:text-white px-3 py-2 rounded-lg text-sm font-medium transition">
                            Admin Settings
                        </a>
                    <?php elseif ($userRole === 'teacher'): ?>
                        <!-- Teacher Links (e.g., Classes, Grading) -->
                        <a href="#" class="text-green-300 hover:bg-indigo-600 hover:text-white px-3 py-2 rounded-lg text-sm font-medium transition">
                            My Classes
                        </a>
                        <a href="#" class="text-green-300 hover:bg-indigo-600 hover:text-white px-3 py-2 rounded-lg text-sm font-medium transition">
                            Grades Entry
                        </a>
                    <?php elseif ($userRole === 'student'): ?>
                        <!-- Student Links (e.g., Grades, Enrollment) -->
                        <a href="#" class="text-blue-300 hover:bg-indigo-600 hover:text-white px-3 py-2 rounded-lg text-sm font-medium transition">
                            View Grades
                        </a>
                    <?php endif; ?>

                    <!-- Logout Button -->
                    <a href="/logout" class="bg-red-500 text-white hover:bg-red-600 px-4 py-2 rounded-lg text-sm font-bold shadow-md transition duration-150">
                        Logout (<?= esc($userName) ?>)
                    </a>
                <?php else: ?>
                    <!-- Common Logged-out Links -->
                    <a href="/login" class="text-white hover:bg-indigo-600 px-3 py-2 rounded-lg text-sm font-medium transition">
                        Login
                    </a>
                    <a href="/register" class="bg-indigo-500 text-white hover:bg-indigo-600 px-3 py-2 rounded-lg text-sm font-medium transition">
                        Register
                    </a>
                <?php endif; ?>
            </nav>
        </div>
    </div>
</header>